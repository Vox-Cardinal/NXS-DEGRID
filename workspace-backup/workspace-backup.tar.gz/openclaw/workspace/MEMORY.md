# MEMORY.md - Long-Term Memory

_Curated memories, distilled from daily notes. Update periodically._

---

## Identity

**Name:** Kimi Claw  
**Role:** AI assistant for NXS development  
**Language:** English (per LANGUAGE.md)  

## Active Projects

### NXS (Next System)
**Status:** Research/Planning phase  
**Location:** `/opt/development/`  
**Rules:** [NXS-DEV-GUIDE.md](/opt/development/NXS-DEV-GUIDE.md)

**Key Constraints:**
- Research/planning only — zero implementation
- Max 75% hardware usage
- Max 2 sub-agents
- Auto-start research unless stopped

**Current Tasks (R000-R007):**
| ID | Task | Priority | Status |
|----|------|----------|--------|
| R000 | NXS Codebase Analysis | Critical | 60% complete |
| R001 | XTTS-v2 Integration | High | Planned |
| R002 | Whisper STT Integration | High | Planned |
| R003 | The Doctor Architecture | High | Planned |
| R004 | URL Frontend Design | High | Planned |
| R005 | Tailscale Integration | Medium | Planned |
| R006 | ComfyUI API Pattern | Medium | Planned |
| R007 | Kimi-Claw Plugin Analysis | Medium | Planned |

## Important References

| File | Purpose |
|------|---------|
| [NXS-DEV-GUIDE.md](/opt/development/NXS-DEV-GUIDE.md) | Development rules & workflow |
| [RESEARCH-TASK-INDEX.md](/opt/development/RESEARCH-TASK-INDEX.md) | Task tracking |
| [DECISION-LOG.md](/opt/development/DECISION-LOG.md) | Architecture decisions |
| [TECHNOLOGY-MATRIX.md](/opt/development/TECHNOLOGY-MATRIX.md) | Technology comparisons |
| [INTEGRATION-PATTERNS.md](/opt/development/INTEGRATION-PATTERNS.md) | Design patterns |
| [Research Memory](/opt/development/memory/) | Daily research logs |

## Credentials

- GitHub token: `~/.openclaw/credentials/github/token.json`
- Used for: Research backup pushes

## System Setup

- **Proxy:** mihomo on 127.0.0.1:7890
- **Gateway:** OpenClaw on 127.0.0.1:18789
- **Health checks:** Cron job every hour

---

*Last updated: 2026-02-20*
